# CC Alpha 0.1 - Native Android

CC is een Android Command Center dat gedachten omzet in overzicht.

Het is geen notitie-app en geen standaard taken-app. Het is een plannings- en actiemanager waarbij schrijven met de S Pen de snelste invoermethode is.

## Alpha 0.1

Deze versie bevat:

- Kotlin + Jetpack Compose
- Landscape-first tablet-layout
- CC-branding als basis
- Focus-scherm
- Master Card
- GitHub Actions workflow voor APK-build

## APK bouwen via GitHub

Ga naar **Actions** en start **Build CC Alpha APK**. Na de build download je het artifact `CC-Alpha-0.1-debug-apk`.
