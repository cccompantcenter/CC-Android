package com.cc.commandcenter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CCAlphaApp() }
    }
}

private val CCMidnight = Color(0xFF070707)
private val CCGraphite = Color(0xFF141414)
private val CCGold = Color(0xFFD6A64A)
private val CCText = Color(0xFFF4EEE3)
private val CCMuted = Color(0xFF9E968B)
private val CCRed = Color(0xFFFF514A)
private val CCAmber = Color(0xFFFFC43D)
private val CCOrange = Color(0xFFFF8A22)

@Composable
fun CCAlphaApp() {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(CCMidnight)
            .padding(18.dp)
    ) {
        Sidebar()
        Spacer(Modifier.width(22.dp))
        FocusPanel(modifier = Modifier.weight(1.15f))
        Spacer(Modifier.width(18.dp))
        MasterCard(modifier = Modifier.weight(1f))
    }
}

@Composable
fun Sidebar() {
    Column(
        modifier = Modifier
            .width(178.dp)
            .fillMaxHeight()
            .background(Color(0xFF0B0B0B), RoundedCornerShape(28.dp))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(28.dp))
            .padding(24.dp)
    ) {
        CCLogo()
        Spacer(Modifier.height(34.dp))
        NavItem("Focus", true)
        NavItem("Reactie afwachten", false)
        NavItem("Taak van anderen", false)
        NavItem("Ideeën", false)
        NavItem("Archief", false)
        Spacer(Modifier.weight(1f))
        Text("Rust in je hoofd.", color = CCMuted, fontSize = 12.sp)
        Text("Focus op vandaag.", color = CCGold, fontSize = 12.sp)
    }
}

@Composable
fun CCLogo() {
    Box(Modifier.height(78.dp).fillMaxWidth()) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            val p1 = Path().apply {
                moveTo(28f, 38f)
                cubicTo(18f, 8f, 74f, 0f, 66f, 32f)
                cubicTo(58f, 60f, 18f, 64f, 28f, 38f)
            }
            val p2 = Path().apply {
                moveTo(72f, 38f)
                cubicTo(62f, 8f, 118f, 0f, 110f, 32f)
                cubicTo(102f, 60f, 62f, 64f, 72f, 38f)
                cubicTo(110f, 48f, 132f, 34f, 148f, 37f)
            }
            drawPath(p1, CCGold, style = stroke)
            drawPath(p2, CCGold, style = stroke)
            drawCircle(CCGold, radius = 3f, center = Offset(151f, 37f))
        }
        Text("COMMAND CENTER", color = CCGold, fontSize = 9.sp, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.BottomStart))
    }
}

@Composable
fun NavItem(text: String, active: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(if (active) Color(0xFF211B11) else Color.Transparent, RoundedCornerShape(15.dp))
            .border(if (active) 1.dp else 0.dp, if (active) CCGold.copy(alpha=.45f) else Color.Transparent, RoundedCornerShape(15.dp))
            .padding(14.dp)
    ) {
        Text(text, color = if (active) CCGold else CCText.copy(alpha=.82f), fontSize = 14.sp)
    }
}

@Composable
fun FocusPanel(modifier: Modifier) {
    Column(modifier.fillMaxHeight().background(CCGraphite, RoundedCornerShape(28.dp)).border(1.dp, Color.White.copy(.09f), RoundedCornerShape(28.dp)).padding(32.dp)) {
        Text("Waar wil je vandaag mee beginnen?", color = CCText, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text("Focus", color = CCGold, fontSize = 19.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            FocusCount("Mijn acties", "4", CCRed, Modifier.weight(1f))
            FocusCount("Reactie afwachten", "3", CCAmber, Modifier.weight(1f))
            FocusCount("Taak van anderen", "2", CCOrange, Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        TaskRow("Teamoverleg voorbereiden", "Wendy Jansen · Vandaag 09:30", CCRed)
        TaskRow("Offerte controleren", "Marco de Wit · Vandaag", CCAmber)
        TaskRow("Linda om feedback vragen", "Linda Bakker · Vrijdag", Color(0xFF3EC6B6))
        Spacer(Modifier.weight(1f))
        WriteButton()
        Spacer(Modifier.height(16.dp))
        Text("Rust in je hoofd. Focus op wat vandaag telt.", color = CCMuted.copy(.65f), fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
fun FocusCount(title: String, count: String, color: Color, modifier: Modifier) {
    Column(modifier.background(Color(0xFF101010), RoundedCornerShape(22.dp)).border(1.dp, color.copy(.45f), RoundedCornerShape(22.dp)).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = CCText, fontSize = 14.sp)
        Text(count, color = CCText, fontSize = 42.sp, fontWeight = FontWeight.Light)
        Text("Vandaag", color = CCMuted, fontSize = 12.sp)
    }
}

@Composable
fun TaskRow(title: String, meta: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Color(0xFF0F0F0F), RoundedCornerShape(18.dp)).border(1.dp, Color.White.copy(.07f), RoundedCornerShape(18.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(46.dp).background(color, RoundedCornerShape(4.dp)))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = CCText, fontSize = 17.sp)
            Text(meta, color = CCMuted, fontSize = 12.sp)
        }
        Text("⋯", color = CCMuted, fontSize = 24.sp)
    }
}

@Composable
fun WriteButton() {
    Row(Modifier.width(360.dp).height(64.dp).background(Brush.horizontalGradient(listOf(Color(0xFF33250D), Color(0xFF120F0A))), RoundedCornerShape(32.dp)).border(1.dp, CCGold, RoundedCornerShape(32.dp)).padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("✍", color = CCGold, fontSize = 24.sp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text("Schrijven", color = CCGold, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Text("Nieuwe notitie vastleggen", color = CCMuted, fontSize = 11.sp)
        }
        Text("→", color = CCGold, fontSize = 28.sp)
    }
}

@Composable
fun MasterCard(modifier: Modifier) {
    Column(modifier.fillMaxHeight().background(CCGraphite, RoundedCornerShape(28.dp)).border(1.dp, Color.White.copy(.09f), RoundedCornerShape(28.dp)).padding(28.dp)) {
        Text("Master Card", color = CCGold, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        Text("Teamoverleg voorbereiden", color = CCText, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))
        Text("Levensloop", color = CCMuted, fontSize = 13.sp)
        Text("Idee  →  Focus  →  Reactie afwachten  →  Archief", color = CCText.copy(.88f), fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        InfoBlock("Persoon", "Wendy Jansen")
        InfoBlock("Datum & tijd", "Dinsdag 6 juli · 09:30 - 10:30")
        InfoBlock("Herinnering", "Iedere 2 weken · tot 31 dec 2026")
        InfoBlock("Prioriteit", "Hoog")
        Spacer(Modifier.height(16.dp))
        Text("Notities", color = CCGold, fontSize = 18.sp)
        Note("3 juli 2026", "Wendy heeft de agenda aangeleverd.")
        Note("5 juli 2026", "Actiepunten besproken met Marco.")
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionChip("Gedaan")
            ActionChip("Later")
            ActionChip("Notitie")
            ActionChip("Verplaatsen")
        }
    }
}

@Composable
fun InfoBlock(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = CCMuted, fontSize = 12.sp)
        Text(value, color = CCText, fontSize = 14.sp)
    }
}

@Composable
fun Note(date: String, text: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Color(0xFF101010), RoundedCornerShape(15.dp)).padding(14.dp)) {
        Text(date, color = CCMuted, fontSize = 11.sp)
        Text(text, color = CCText, fontSize = 13.sp)
    }
}

@Composable
fun ActionChip(text: String) {
    Box(Modifier.background(Color(0xFF101010), RoundedCornerShape(18.dp)).border(1.dp, CCGold.copy(.35f), RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text(text, color = CCText, fontSize = 12.sp)
    }
}
