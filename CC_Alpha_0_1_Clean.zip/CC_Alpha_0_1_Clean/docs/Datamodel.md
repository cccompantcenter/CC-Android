# Datamodel

## Card
- Titel
- Omschrijving
- Categorie
- Persoon
- Status
- Prioriteit
- Herinnering
- Tijdlijn
- Notities
