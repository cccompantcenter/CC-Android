# Productvisie

CC is een Android Command Center waarin schrijven de snelste manier is om werk te organiseren.

Alles is een kaart. Focus is het hart. Schrijven is de primaire invoer.
