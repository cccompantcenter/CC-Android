# Bouwlog

## Alpha 0.1
- Schone Android-projectstructuur gemaakt.
- Focus en Master Card als eerste scherm opgebouwd.
- GitHub Actions toegevoegd voor APK-build.
