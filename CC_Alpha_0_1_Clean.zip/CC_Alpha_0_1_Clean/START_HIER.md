# Start hier

1. Upload deze volledige projectstructuur naar GitHub.
2. Ga naar Actions.
3. Kies Build CC Alpha APK.
4. Download na afloop de APK uit Artifacts.
5. Installeer de APK op de Samsung Tab S10 Lite.
